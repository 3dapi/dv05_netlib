// Client Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>


#include "../include/LcDB/ILcDB.h"


ILcDB*		g_pDataBase=NULL;													// DataBase Instance


int main()
{
	char	sDBtype[32];
	char	sFile[MAX_PATH];
	char	sSQL[512];
	
//	strcpy(sDBtype, "DSN");
	strcpy(sDBtype, "excel");
//	strcpy(sDBtype, "MDB");
		
//	strcpy(sFile, "MdbUsr");
	strcpy(sFile, "database/user.xls");
//	strcpy(sFile, "database/user.mdb");

//	strcpy(sSQL, "select name,skill,hp from tblUsr");
	strcpy(sSQL, "select name,skill,hp from [Sheet1$]");
//	strcpy(sSQL, "select name,skill,hp from tblUsr");


	if(FAILED(LnDB_CreateAndConnect("ODBC", &g_pDataBase, sDBtype, sFile)))
		return -1;


	INT		nBufSize= 1024;
	char**	sDataBuf= NULL;
	INT*	nDataBuf= NULL;
	INT		iColumn	= 0;


//	for(int j=0; j<3; ++j)
	{
		iColumn = g_pDataBase->SqlBind(sSQL, &sDataBuf, &nDataBuf, nBufSize);

		if(SUCCEEDED(iColumn))
		{
			printf("�̸�                   ����ġ                       ü��\n");
			printf("--------------------------------------------------\n");

			while(1)
			{
				if(FAILED(g_pDataBase->SqlExec()))
					break;

				for(int i=0; i<iColumn; ++i)
				{
					printf("%12s(%2d)	", sDataBuf[i], nDataBuf[i]);
				}

				printf("\n");
			}

			g_pDataBase->SqlClose();

			printf("--------------------------------------------------\n\n");
		}
	}


	g_pDataBase->Close();

	delete g_pDataBase;
	
	return 1;
}


