//  Main() �Լ�
//

#include <iostream>
#include <windows.h>

#include "Queue.h"

int main()
{
	std::cout<< "������ ����ť ���α׷�.\n\n";

	int i,j;

	CQueCircular*	pQueue = new CQueCircular(20);

	
	for(i=0; i<10; ++i)
	{
		for(j=0; j<30; ++j)
		{
			pQueue->Enqueue(i*30 + j);
		}

		for(j=0; j<30; ++j)
		{
			int iVal = 0;
			pQueue->Dequeue(&iVal);

			printf("%d\n",iVal);
		}
	}

	delete pQueue;
	return 0;
}
